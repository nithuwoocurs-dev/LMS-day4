<?php
include 'config.php';

// --- Search handling ---
$search = isset($_GET['search']) ? $_GET['search'] : '';

$sql = "SELECT * FROM entries 
        WHERE name LIKE '%$search%' OR email LIKE '%$search%' 
        ORDER BY id DESC";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>View Entries - My Project</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">

  <h2 class="mb-4">ALL ENTRIES</h2>

  <!-- ✅ Success Message -->
  <?php if (isset($_GET['msg'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <?php 
        if ($_GET['msg'] == 'updated') echo "✅ Record updated successfully!";
        if ($_GET['msg'] == 'deleted') echo "🗑️ Record deleted successfully!";
      ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <!-- Search Form -->
  <form method="GET" class="mb-3">
      <input type="text" name="search" class="form-control" 
             placeholder="Search by Name or Email"
             value="<?php if(isset($_GET['search'])) echo $_GET['search']; ?>">
  </form>

  <!-- Table -->
  <table class="table table-bordered table-striped table-hover">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Created At</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php 
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>
              <td>{$row['id']}</td>
              <td>{$row['name']}</td>
              <td>{$row['email']}</td>
              <td>{$row['phone']}</td>
              <td>{$row['created_at']}</td>
              <td>
                <a href='update.php?id={$row['id']}' class='btn btn-sm btn-primary'>Edit</a>
                <a href='delete.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure?\");'>Delete</a>
              </td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='6' class='text-center'>No entries found</td></tr>";
    }
    ?>
    </tbody>
  </table>
</div>

<!-- Bootstrap JS for dismissible alert -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
